import { Team } from './types';

export const TEAMS: Team[] = [
  {
    id: 'team_a',
    name: 'Crimson Cobras',
    color: 'text-red-500',
    logo: '🐍'
  },
  {
    id: 'team_b',
    name: 'Azure Eagles',
    color: 'text-blue-500',
    logo: '🦅'
  },
  {
    id: 'team_c',
    name: 'Emerald Vipers',
    color: 'text-emerald-500',
    logo: '🐊'
  }
];
