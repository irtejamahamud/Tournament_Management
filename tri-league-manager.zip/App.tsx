import React, { useState, useEffect, useMemo } from 'react';
import { TEAMS } from './constants';
import { initializeSchedule, calculateStandings } from './utils/calculations';
import { Match, MatchStatus, MatchType } from './types';
import StandingsTable from './components/StandingsTable';
import MatchCard from './components/MatchCard';
import { Trophy, RefreshCw, Dna, Lock } from 'lucide-react';

const App: React.FC = () => {
  const [matches, setMatches] = useState<Match[]>([]);
  const [init, setInit] = useState(false);

  // Initialize schedule on mount
  useEffect(() => {
    // Check localStorage first
    const savedMatches = localStorage.getItem('tri_league_matches');
    if (savedMatches) {
        setMatches(JSON.parse(savedMatches));
    } else {
        setMatches(initializeSchedule(TEAMS));
    }
    setInit(true);
  }, []);

  // Save to localStorage whenever matches change
  useEffect(() => {
      if(init) {
        localStorage.setItem('tri_league_matches', JSON.stringify(matches));
      }
  }, [matches, init]);

  // Derived State: Standings
  const standings = useMemo(() => calculateStandings(TEAMS, matches), [matches]);

  // Handle Score Updates
  const updateScore = (matchId: string, homeScoreStr: string, awayScoreStr: string) => {
    setMatches(prevMatches => {
      return prevMatches.map(m => {
        if (m.id !== matchId) return m;

        const homeScore = homeScoreStr === '' ? null : parseInt(homeScoreStr);
        const awayScore = awayScoreStr === '' ? null : parseInt(awayScoreStr);
        
        let status = MatchStatus.SCHEDULED;
        if (homeScore !== null && awayScore !== null) {
          status = MatchStatus.COMPLETED;
        }

        return { ...m, homeScore, awayScore, status };
      });
    });
  };

  // Logic to Generate or Update Final
  useEffect(() => {
    if (!init) return;

    const groupMatches = matches.filter(m => m.type === MatchType.GROUP);
    const allGroupCompleted = groupMatches.every(m => m.status === MatchStatus.COMPLETED);
    
    // Check if final exists
    const existingFinalIndex = matches.findIndex(m => m.type === MatchType.FINAL);
    const finalExists = existingFinalIndex !== -1;

    if (allGroupCompleted) {
      // Get top 2 teams
      const topTwo = standings.slice(0, 2);
      const homeId = topTwo[0].id;
      const awayId = topTwo[1].id;
      
      if (!finalExists) {
        // Create new final
        const finalMatch: Match = {
          id: `match_final`,
          homeTeamId: homeId,
          awayTeamId: awayId,
          homeScore: null,
          awayScore: null,
          status: MatchStatus.SCHEDULED,
          type: MatchType.FINAL
        };
        setMatches(prev => [...prev, finalMatch]);
      } else {
        // Check if we need to update the existing final (if standings changed top 2)
        const currentFinal = matches[existingFinalIndex];
        if (currentFinal.homeTeamId !== homeId || currentFinal.awayTeamId !== awayId) {
             setMatches(prev => {
                 const updated = [...prev];
                 updated[existingFinalIndex] = {
                     ...updated[existingFinalIndex],
                     homeTeamId: homeId,
                     awayTeamId: awayId,
                     // Reset scores if teams change
                     homeScore: null,
                     awayScore: null,
                     status: MatchStatus.SCHEDULED
                 };
                 return updated;
             });
        }
      }
    } else if (finalExists) {
        // Edge case: If user clears a score in group stage, remove the final
        setMatches(prev => prev.filter(m => m.type !== MatchType.FINAL));
    }
  }, [matches, standings, init]);

  const handleReset = () => {
    if (window.confirm("Are you sure you want to reset the entire tournament?")) {
        setMatches(initializeSchedule(TEAMS));
    }
  };

  const getTeam = (id: string) => TEAMS.find(t => t.id === id)!;

  const finalMatch = matches.find(m => m.type === MatchType.FINAL);
  const groupMatches = matches.filter(m => m.type === MatchType.GROUP);

  return (
    <div className="min-h-screen bg-slate-950 pb-20">
        
      {/* Navbar */}
      <nav className="bg-slate-900 border-b border-slate-800 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="bg-indigo-600 p-2 rounded-lg">
                <Dna className="w-6 h-6 text-white" />
              </div>
              <h1 className="text-xl font-bold text-white tracking-tight">Tri-League <span className="text-indigo-400 font-light">Manager</span></h1>
            </div>
            <button 
                onClick={handleReset}
                className="text-slate-400 hover:text-white transition-colors p-2 rounded-full hover:bg-slate-800"
                title="Reset Tournament"
            >
                <RefreshCw className="w-5 h-5" />
            </button>
          </div>
        </div>
      </nav>

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8">
        
        {/* Top Section: Standings & Final Promo */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            
            {/* Left: Standings Table */}
            <div className="lg:col-span-2 space-y-6">
                 <StandingsTable stats={standings} />
                 
                 {/* Match List Grid */}
                 <div className="space-y-4">
                    <h3 className="text-xl font-bold text-white flex items-center gap-2">
                        <span className="w-2 h-8 bg-indigo-500 rounded-full"></span>
                        Match Schedule
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                        {groupMatches.map(match => (
                            <MatchCard 
                                key={match.id}
                                match={match}
                                homeTeam={getTeam(match.homeTeamId)}
                                awayTeam={getTeam(match.awayTeamId)}
                                onUpdateScore={updateScore}
                            />
                        ))}
                    </div>
                 </div>
            </div>

            {/* Right: Finals Area (Sticky on Desktop) */}
            <div className="lg:col-span-1">
                <div className="sticky top-24 space-y-6">
                    <div className="bg-slate-900 rounded-2xl p-6 border border-slate-800 shadow-2xl relative overflow-hidden group">
                        
                        {/* Background Decoration */}
                        <div className="absolute top-0 right-0 w-32 h-32 bg-amber-500/10 rounded-full blur-3xl -mr-16 -mt-16 pointer-events-none"></div>
                        <div className="absolute bottom-0 left-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-3xl -ml-16 -mb-16 pointer-events-none"></div>

                        <div className="flex items-center gap-3 mb-4 relative z-10">
                            <Trophy className={`w-8 h-8 ${finalMatch ? 'text-amber-400' : 'text-slate-600'}`} />
                            <div>
                                <h2 className="text-xl font-bold text-white">The Final</h2>
                                <p className="text-xs text-slate-400 uppercase tracking-wider">Championship Match</p>
                            </div>
                        </div>

                        {finalMatch ? (
                            <div className="animate-in fade-in slide-in-from-bottom-4 duration-700">
                                <p className="text-sm text-slate-300 mb-4">
                                    The group stage has concluded. The top two teams face off for glory!
                                </p>
                                <MatchCard 
                                    match={finalMatch}
                                    homeTeam={getTeam(finalMatch.homeTeamId)}
                                    awayTeam={getTeam(finalMatch.awayTeamId)}
                                    onUpdateScore={updateScore}
                                    isFinal={true}
                                />
                            </div>
                        ) : (
                            <div className="text-center py-10 border-2 border-dashed border-slate-800 rounded-xl bg-slate-900/50">
                                <div className="mx-auto w-12 h-12 bg-slate-800 rounded-full flex items-center justify-center mb-3">
                                    <Lock className="w-5 h-5 text-slate-500" />
                                </div>
                                <h4 className="text-slate-300 font-medium">Final Locked</h4>
                                <p className="text-sm text-slate-500 mt-1 max-w-[200px] mx-auto">
                                    Complete all 6 group matches to unlock the final match.
                                </p>
                                <div className="mt-4 w-full bg-slate-800 rounded-full h-2 overflow-hidden">
                                    <div 
                                        className="bg-indigo-600 h-full transition-all duration-500" 
                                        style={{ width: `${(groupMatches.filter(m => m.status === MatchStatus.COMPLETED).length / 6) * 100}%` }}
                                    ></div>
                                </div>
                                <p className="text-xs text-slate-500 mt-2">
                                    {groupMatches.filter(m => m.status === MatchStatus.COMPLETED).length} / 6 Matches Played
                                </p>
                            </div>
                        )}
                    </div>
                    
                    {/* Rules Summary */}
                    <div className="bg-slate-900/50 rounded-xl p-5 border border-slate-800/50">
                        <h4 className="text-sm font-semibold text-slate-300 mb-2">Tournament Format</h4>
                        <ul className="text-xs text-slate-500 space-y-2 list-disc pl-4">
                            <li>Double Round-Robin (Home & Away).</li>
                            <li>Win: 3 pts, Draw: 1 pt, Loss: 0 pts.</li>
                            <li>Tie-breakers: Points &gt; Goal Diff &gt; Goals For.</li>
                            <li>Top 2 teams advance to the Final.</li>
                        </ul>
                    </div>
                </div>
            </div>

        </div>

      </main>
    </div>
  );
};

export default App;